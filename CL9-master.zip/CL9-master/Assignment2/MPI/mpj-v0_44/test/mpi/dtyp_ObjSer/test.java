package mpi.dtyp_ObjSer;

import java.io.*;

public class test implements Serializable {

  public int a = 112;
  public String b = "test1";
  public int c = 999;
}
